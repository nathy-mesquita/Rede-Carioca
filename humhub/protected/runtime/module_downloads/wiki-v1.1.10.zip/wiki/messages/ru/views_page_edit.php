<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Создать</strong> новую страницу',
  '<strong>Edit</strong> page' => '<strong>Редактировать</strong> страницу',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Введите название страницы wiki или ссылку (например http://example.com)',
  'New page title' => 'Название новой страницы',
  'Page content' => 'Содержание страницы',
  'Save' => 'Сохранить',
);
