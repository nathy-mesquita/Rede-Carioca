<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Crear</strong> nueva página',
  '<strong>Edit</strong> page' => '<strong>Editar</strong> página',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Escribe el nombre de la wiki o la dirección (ej. http://ejemplo.com)',
  'New page title' => 'Nuevo título de la página',
  'Page content' => 'Contenido de la página',
  'Save' => 'Guardar',
);
