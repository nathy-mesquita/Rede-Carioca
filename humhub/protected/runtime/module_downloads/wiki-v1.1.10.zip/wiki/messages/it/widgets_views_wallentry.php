<?php
return array (
  'Open wiki page...' => 'Apri pagina wiki...',
);
