<?php
return array (
  '<strong>Create</strong> new page' => '<strong>Kreiraj</strong> novu stranicu',
  '<strong>Edit</strong> page' => '<strong>Uredi</strong> stranicu',
  'Enter a wiki page name or url (e.g. http://example.com)' => 'Unesite naziv wiki stranice ili url (e.g. http://example.com)',
  'New page title' => 'Novi naziv stranice',
  'Page content' => 'Sadržaj stranice',
  'Save' => 'Spremi',
);
