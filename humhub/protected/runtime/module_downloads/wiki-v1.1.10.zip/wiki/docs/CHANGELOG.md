Changelog
=========

1.1.10
-------------------
- Enh: Added Page count configuration

