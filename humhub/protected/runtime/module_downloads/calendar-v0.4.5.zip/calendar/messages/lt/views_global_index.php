<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtruoti</strong> renginius',
  '<strong>Select</strong> calendars' => '<strong>Pasirinkti</strong> kalendorių',
  'Already responded' => 'Jau atsakyta',
  'Followed spaces' => 'Sekamos erdvės',
  'Followed users' => 'Sekami vartotojai',
  'I´m attending' => 'Dalyvauju',
  'My events' => 'Mano įvykiai',
  'My profile' => 'Mano profilis',
  'My spaces' => 'Mano erdvės',
  'Not responded yet' => 'Kol kas neatsakyta',
);
