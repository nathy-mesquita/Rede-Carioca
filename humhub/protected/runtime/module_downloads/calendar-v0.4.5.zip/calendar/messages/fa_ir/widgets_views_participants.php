<?php
return array (
  ':count attending' => 'شمارش حاضرین:',
  ':count declined' => 'شمارش انصراف‌ها:',
  ':count maybe' => 'شمارش احتمالی‌ها:',
  'Participants:' => 'مشارکت‌کننده‌ها:',
);
