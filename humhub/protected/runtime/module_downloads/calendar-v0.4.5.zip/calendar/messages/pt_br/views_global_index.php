<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtrar</strong> eventos',
  '<strong>Select</strong> calendars' => '<strong>Selecionar</strong> calendários',
  'Already responded' => 'Já respondeu',
  'Followed spaces' => 'Espaços seguidos',
  'Followed users' => 'Usuários seguidos',
  'I´m attending' => 'Estou participando',
  'My events' => 'Meus eventos',
  'My profile' => 'Meu perfil',
  'My spaces' => 'Meus espaços',
  'Not responded yet' => 'Ainda não respondeu',
);
