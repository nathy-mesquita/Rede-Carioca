<?php
return array (
  ':count attending' => ':katılan',
  ':count declined' => ':katılmayan',
  ':count maybe' => ':belki katılan',
  'Participants:' => 'Katılımcılar',
);
