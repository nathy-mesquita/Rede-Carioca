<?php
return array (
  ':count attending' => 'bisa menghadiri',
  ':count declined' => 'tidak menghadiri',
  ':count maybe' => 'mungkin',
  'Participants:' => 'Partisipasi',
);
