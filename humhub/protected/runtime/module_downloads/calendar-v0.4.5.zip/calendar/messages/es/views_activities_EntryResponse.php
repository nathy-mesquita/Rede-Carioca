<?php
return array (
  '%displayName% attends to %contentTitle%.' => '%displayName% asistirá a %contentTitle%.',
  '%displayName% maybe attends to %contentTitle%.' => '%displayName% tal vez asista a %contentTitle%.',
  '%displayName% not attends to %contentTitle%.' => '%displayName% no asistirá a %contentTitle%.',
);
