<?php
return array (
  '<strong>Filter</strong> events' => 'Termine <strong>filtern</strong>',
  '<strong>Select</strong> calendars' => 'Kalender <strong>filtern</strong>',
  'Already responded' => 'Beantwortet',
  'Followed spaces' => 'Gefolgte Spaces',
  'Followed users' => 'Gefolgte Benutzer',
  'I´m attending' => 'Ich nehme teil',
  'My events' => 'Meine Termine',
  'My profile' => 'Mein Profil',
  'My spaces' => 'Meine Spaces',
  'Not responded yet' => 'Nicht beantwortet',
);
