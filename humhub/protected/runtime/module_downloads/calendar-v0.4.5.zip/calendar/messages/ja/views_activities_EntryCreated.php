<?php
return array (
  '%displayName% created a new %contentTitle%.' => '%displayName%は新しい%contentTitle%を作成しました。',
);
