<?php
return array (
  '<strong>Filter</strong> events' => '<strong>Filtrează</strong> evenimentele',
  '<strong>Select</strong> calendars' => '<strong>Selectează</strong> calendare',
  'Already responded' => 'Ai răspuns deja',
  'Followed spaces' => 'Spații urmărite',
  'Followed users' => 'Utilizatori urmăriți',
  'I´m attending' => 'Particip',
  'My events' => 'Evenimentele mele',
  'My profile' => 'Profilul meu',
  'My spaces' => 'Spațiile mele',
  'Not responded yet' => 'Nu am răspuns încă',
);
