<?php

return [
    'humhub_root' => 'E:\codebase\humhub\master',
    'modules' => ['calendar'],
    'fixtures' => [
        'default',
        'calendar_entry' => 'humhub\modules\calendar\tests\codeception\fixtures\CalendarEntryFixture'
    ]
];



